import { useState, useEffect } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { cn } from '@/lib/utils'
import {
  Package,
  X,
  ChevronDown,
  User,
  Settings,
} from 'lucide-react'
import { navItems, filterVisibleNav } from '@/config/nav'
import { useAuth } from '@/contexts/AuthContext'

export type { NavItem } from '@/config/nav'

interface SidebarProps {
  isOpen: boolean
  onToggle: () => void
}

const EXPANDED_STORAGE_KEY = 'sidebar:expanded'

function getInitialExpanded(pathname: string): Set<string> {
  const expanded = new Set<string>()
  try {
    const stored = sessionStorage.getItem(EXPANDED_STORAGE_KEY)
    if (stored) {
      JSON.parse(stored).forEach((id: string) => expanded.add(id))
    }
  } catch {
    // ignore
  }
  // Auto-expand the parent section matching the current route
  for (const item of navItems) {
    if (!item.children || item.children.length === 0) continue
    if (pathname === item.path || pathname.startsWith(item.path + '/')) {
      expanded.add(item.id)
    }
  }
  return expanded
}

export default function Sidebar({ isOpen, onToggle }: SidebarProps) {
  const location = useLocation()
  const navigate = useNavigate()
  const { user } = useAuth()
  const tienePermiso = (clave?: string) => {
    if (!clave) return true
    if (!user) return false
    if (user.es_sistema) return true
    return (user.permisos ?? []).includes(clave)
  }
  const visibleNavItems = filterVisibleNav(navItems, tienePermiso)
  const [expandedItems, setExpandedItems] = useState<Set<string>>(() =>
    getInitialExpanded(location.pathname)
  )

  // Keep the active parent section expanded on route changes
  useEffect(() => {
    setExpandedItems((prev) => {
      const next = new Set(prev)
      for (const item of visibleNavItems) {
        if (!item.children || item.children.length === 0) continue
        if (location.pathname === item.path || location.pathname.startsWith(item.path + '/')) {
          next.add(item.id)
        }
      }
      return next
    })
  }, [location.pathname])

  // Persist manual toggles across remounts
  useEffect(() => {
    try {
      sessionStorage.setItem(EXPANDED_STORAGE_KEY, JSON.stringify(Array.from(expandedItems)))
    } catch {
      // ignore
    }
  }, [expandedItems])

  const toggleExpand = (itemId: string) => {
    setExpandedItems((prev) => {
      const newSet = new Set(prev)
      if (newSet.has(itemId)) {
        newSet.delete(itemId)
      } else {
        newSet.add(itemId)
      }
      return newSet
    })
  }

  const isActive = (path: string) => {
    if (path === '/') return location.pathname === '/'
    return location.pathname === path || location.pathname.startsWith(path + '/')
  }

  return (
    <>
      {isOpen && (
        <div
          onClick={onToggle}
          className="fixed inset-0 z-40 bg-black/50 lg:hidden"
        />
      )}

      <aside
        className={cn(
          'fixed left-0 top-0 z-50 h-full w-64 bg-card border-r border-border transition-transform duration-300 lg:translate-x-0',
          isOpen ? 'translate-x-0' : '-translate-x-full'
        )}
      >
        <div className="flex h-16 items-center justify-between border-b border-border px-4">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded bg-primary">
              <Package className="h-5 w-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold text-foreground">RedPrint</span>
          </div>
          <button
            onClick={onToggle}
            className="rounded-md p-2 hover:bg-muted lg:hidden"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto py-4">
          <ul className="space-y-1 px-3">
            {visibleNavItems.map((item) => {
              const Icon = item.icon
              const hasChildren = item.children && item.children.length > 0
              const isExpanded = expandedItems.has(item.id)
              const active = isActive(item.path)

              return (
                <li key={item.id}>
                  {hasChildren ? (
                    <button
                      onClick={() => toggleExpand(item.id)}
                      className={cn(
                        'flex w-full items-center justify-between rounded-md px-3 py-2 text-sm font-medium transition-colors',
                        active
                          ? 'bg-primary/10 text-primary'
                          : 'text-foreground hover:bg-muted'
                      )}
                    >
                      <div className="flex items-center gap-3">
                        <Icon className="h-5 w-5" />
                        <span>{item.label}</span>
                        {item.badge && (
                          <span className="ml-auto rounded-full bg-destructive px-2 py-0.5 text-xs text-destructive-foreground">
                            {item.badge}
                          </span>
                        )}
                      </div>
                      <ChevronDown
                        className={cn('h-4 w-4 transition-transform', isExpanded && 'rotate-180')}
                      />
                    </button>
                  ) : (
                    <Link
                      to={item.path}
                      className={cn(
                        'flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors',
                        active
                          ? 'bg-primary/10 text-primary'
                          : 'text-foreground hover:bg-muted'
                      )}
                    >
                      <Icon className="h-5 w-5" />
                      <span>{item.label}</span>
                      {item.badge && (
                        <span className="ml-auto rounded-full bg-destructive px-2 py-0.5 text-xs text-destructive-foreground">
                          {item.badge}
                        </span>
                      )}
                    </Link>
                  )}

                  {hasChildren && isExpanded && (
                    <ul className="ml-6 mt-1 space-y-1">
                      {item.children?.map((child) => (
                        <li key={child.id}>
                          <Link
                            to={child.path}
                            className={cn(
                              'flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors',
                              isActive(child.path)
                                ? 'bg-primary/10 text-primary'
                                : 'text-foreground hover:bg-muted'
                            )}
                          >
                            <child.icon className="h-4 w-4" />
                            <span>{child.label}</span>
                            {child.badge && (
                              <span className="ml-auto rounded-full bg-destructive px-1.5 py-0.5 text-xs text-destructive-foreground">
                                {child.badge}
                              </span>
                            )}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  )}
                </li>
              )
            })}
          </ul>
        </nav>

        <div className="border-t border-border p-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-muted">
              <User className="h-5 w-5 text-muted-foreground" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-foreground">{user?.nombre ?? 'Usuario'}</p>
              <p className="text-xs text-muted-foreground">
                {user ? (user.rol_nombre ?? (user.es_sistema ? 'Administrador' : 'Usuario')) : ''}
              </p>
            </div>
            <button
              className="rounded-md p-2 hover:bg-muted"
              onClick={() => navigate('/sistema/configuracion')}
              title="Configuración del sistema"
            >
              <Settings className="h-4 w-4 text-muted-foreground" />
            </button>
          </div>
        </div>
      </aside>
    </>
  )
}

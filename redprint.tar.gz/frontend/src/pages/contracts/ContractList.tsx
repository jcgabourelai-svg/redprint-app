import { useNavigate } from 'react-router-dom'
import { Plus, FileText } from 'lucide-react'
import PageLayout from '@/components/layout/PageLayout'
import Table from '@/components/ui/Table'
import EmptyState from '@/components/ui/EmptyState'
import Button from '@/components/ui/Button'
import Badge from '@/components/ui/Badge'
import type { Contract, ContractStatus } from '@/types/contract'
import api from '@/lib/api'
import { useServerTable } from '@/hooks/useServerTable'
import { formatDate } from '@/lib/formatters'
import { parseApiError } from '@/lib/api-errors'

const estadoLabels: Record<ContractStatus, string> = {
  ACTIVO: 'Activo',
  SUSPENDIDO: 'Suspendido',
  FINALIZADO: 'Finalizado',
  CANCELADO: 'Cancelado',
}

function getEsquemaLabel(contract: Contract): string {
  if (contract.tarifa_base === 0 && contract.paginas_incluidas === 0) return 'Puro consumo'
  if (contract.costo_por_pagina_excedente === 0) return 'Renta fija'
  return 'Tarifa base + páginas excedentes'
}

export default function ContractList() {
  const navigate = useNavigate()
  const { data: contracts, tableProps, isLoading, error, hasActiveFilters } = useServerTable<Contract>({
    queryKey: ['contracts'],
    fetcher: (p) => api.get('/contracts', { params: p }).then((r) => r.data),
  })

  if (isLoading) {
    return (
      <PageLayout title="Contratos" showSearch>
        <div className="flex items-center justify-center py-12">
          <p className="text-muted-foreground">Cargando contratos...</p>
        </div>
      </PageLayout>
    )
  }

  if (error) {
    return (
      <PageLayout title="Contratos" showSearch>
        <div className="flex items-center justify-center py-12">
          <p className="text-destructive">{parseApiError(error)}</p>
        </div>
      </PageLayout>
    )
  }

  const columns = [
    {
      key: 'id',
      label: 'Contrato',
      sortable: true,
      render: (_value: string, row: Contract) => (
        <div>
          <p className="font-medium text-foreground">{row.codigo_negocio || `Contrato #${row.id}`}</p>
          <p className="text-xs text-muted-foreground">{formatDate(row.fecha_inicio)}</p>
        </div>
      ),
    },
    {
      key: 'cliente_nombre',
      label: 'Cliente',
      sortable: true,
      render: (_value: string, row: Contract) => (
        <div>
          <p className="font-medium text-foreground">{row.cliente_nombre}</p>
          <p className="text-xs text-muted-foreground">{row.cliente_contacto}</p>
        </div>
      ),
    },
    {
      key: 'impresoras',
      label: 'Impresoras',
      render: (_value: unknown, row: Contract) => {
        const asignaciones = row.impresoras ?? []
        const series =
          asignaciones.length > 0
            ? asignaciones.map((a) => a.impresora_serie)
            : (row.printers ?? []).map((p) => p.num_serie)
        return (
          <div>
            <p className="font-medium">{series.length}</p>
            <div className="text-xs text-muted-foreground">
              {series.slice(0, 2).join(', ')}
              {series.length > 2 && '...'}
            </div>
            {(row.pendientes_instalacion ?? 0) > 0 && (
              <Badge variant="warning" className="mt-1">
                Pendiente de instalación
              </Badge>
            )}
          </div>
        )
      },
    },
    {
      key: 'tarifa_base',
      label: 'Esquema de Cobro',
      render: (_value: unknown, row: Contract) => (
        <span className="text-sm">{getEsquemaLabel(row)}</span>
      ),
    },
    {
      key: 'estado',
      label: 'Estado',
      sortable: true,
      render: (value: ContractStatus) => (
        <Badge variant="contract_status" color={value}>
          {estadoLabels[value]}
        </Badge>
      ),
    },
  ]

  return (
    <PageLayout title="Contratos" showSearch>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-foreground">Contratos</h2>
            <p className="text-sm text-muted-foreground">
              Gestión de contratos de renta de impresoras
            </p>
          </div>
          <Button onClick={() => navigate('/contratos/crear')}>
            <Plus className="mr-2 h-4 w-4" />
            Nuevo Contrato
          </Button>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">Estado:</span>
            <select
              className="rounded-md border border-input py-1.5 px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
              value={tableProps.filterState.estado || ''}
              onChange={(e) => tableProps.onFilterChange({ ...tableProps.filterState, estado: e.target.value })}
            >
              <option value="">Todos</option>
              <option value="ACTIVO">Activo</option>
              <option value="SUSPENDIDO">Suspendido</option>
              <option value="FINALIZADO">Finalizado</option>
              <option value="CANCELADO">Cancelado</option>
            </select>
          </div>
          {(tableProps.filterState.estado || '') !== '' && (
            <Button variant="ghost" size="sm" onClick={() => tableProps.onFilterChange({ ...tableProps.filterState, estado: '' })}>
              Limpiar filtros
            </Button>
          )}
        </div>

        {contracts.length === 0 && !hasActiveFilters ? (
          <EmptyState
            icon={FileText}
            title="No hay contratos"
            description="Crea un contrato para vincular un cliente con una impresora."
            action={{ label: 'Nuevo Contrato', onClick: () => navigate('/contratos/crear') }}
          />
        ) : (
          <Table
            data={contracts}
            columns={columns}
            searchable={true}
            sortable={true}
            paginatable={true}
            {...tableProps}
            emptyMessage="No se encontraron contratos con los filtros aplicados."
            onRowClick={(contract) => navigate(`/contratos/${contract.id}`)}
          />
        )}
      </div>
    </PageLayout>
  )
}
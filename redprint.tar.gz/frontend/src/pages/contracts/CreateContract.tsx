import { useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import {
  ArrowLeft,
  Check,
  Printer,
  FileText,
  DollarSign,
  ClipboardCheck,
  Package,
  Plus,
  Trash2,
} from 'lucide-react'
import PageLayout from '@/components/layout/PageLayout'
import Button from '@/components/ui/Button'
import Input from '@/components/ui/Input'
import Select from '@/components/ui/Select'
import Badge from '@/components/ui/Badge'
import Checkbox from '@/components/ui/Checkbox'
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/Card'
import Modal from '@/components/ui/Modal'
import { useClients, useClient } from '@/hooks/useClients'
import { usePrinters } from '@/hooks/usePrinters'
import { usePrinterModels } from '@/hooks/usePrinterCatalog'
import { useCreateContract } from '@/hooks/useContracts'
import type { VisitFrequency } from '@/types/contract'
import { DIAS_GRACIA_LABEL, DIAS_GRACIA_HELP } from './contractLabels'
import { formatCurrency } from '@/lib/formatters'
import { parseApiError } from '@/lib/api-errors'

const stepLabels = ['Datos Generales', 'Impresoras', 'Configurar Tarifa', 'Confirmación']
const stepIcons = [FileText, Printer, DollarSign, ClipboardCheck]

const frecuenciaOptions = [
  { value: 'MENSUAL', label: 'Mensual' },
  { value: 'QUINCENAL', label: 'Quincenal' },
  { value: 'SEMANAL', label: 'Semanal' },
  { value: 'CUSTOM', label: 'Personalizado' },
]

const presetLabels: Record<string, { tarifa_base: number; paginas_incluidas: number; costo_por_pagina_excedente: number }> = {
  renta_fija: { tarifa_base: 1500, paginas_incluidas: 999999, costo_por_pagina_excedente: 0 },
  puro_consumo: { tarifa_base: 0, paginas_incluidas: 0, costo_por_pagina_excedente: 0.02 },
  estandar: { tarifa_base: 1500, paginas_incluidas: 500, costo_por_pagina_excedente: 0.01 },
}

interface PlanRow {
  modelo_id: string
  cantidad: string
}

export default function CreateContract() {
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const [step, setStep] = useState(0)
  const [showConfirm, setShowConfirm] = useState(false)
  const [showSuccess, setShowSuccess] = useState(false)
  const [error, setError] = useState('')

  const clienteIdParam = searchParams.get('cliente_id') ?? ''
  const { data: clientsData, isLoading: clientsLoading } = useClients({ per_page: 100 })
  const { data: prefillClient } = useClient(Number(clienteIdParam))
  const { data: printersData, isLoading: printersLoading } = usePrinters({ estado: 'EN_ALMACEN' })
  const { data: printerModels, isLoading: modelsLoading } = usePrinterModels(undefined, true)
  const createContract = useCreateContract()

  const baseClients = clientsData?.data || []
  const clients =
    prefillClient && !baseClients.some((c) => String(c.id) === String(prefillClient.id))
      ? [prefillClient, ...baseClients]
      : baseClients
  const printers = printersData?.data || []
  const models = printerModels || []

  const today = new Date()
  const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`

  const [cliente_id, setClienteId] = useState(clienteIdParam)
  const [fecha_inicio, setFechaInicio] = useState(todayStr)
  const [fecha_fin, setFechaFin] = useState('')
  const [dias_gracia, setDiasGracia] = useState('7')
  const [frecuencia, setFrecuencia] = useState<VisitFrequency>('MENSUAL')
  const [dia_visita, setDiaVisita] = useState('')

  const [selectedPrinters, setSelectedPrinters] = useState<string[]>([])
  const [lecturas_iniciales, setLecturasIniciales] = useState<Record<string, string>>({})
  const [aliases, setAliases] = useState<Record<string, string>>({})
  const [planRows, setPlanRows] = useState<PlanRow[]>([])
  const [showSeries, setShowSeries] = useState(false)

  const [tarifa_base, setTarifaBase] = useState('1500')
  const [paginas_incluidas, setPaginasIncluidas] = useState('500')
  const [costo_por_pagina_excedente, setCostoPorPagina] = useState('0.01')

  const [programarVisitaInstalacion, setProgramarVisitaInstalacion] = useState(true)
  const [fechaVisitaInstalacion, setFechaVisitaInstalacion] = useState('')

  const clientOptions = clients.map((c) => ({
    value: String(c.id),
    label: `${c.razon_social} (${c.nombre_contacto})`,
  }))

  const modelOptions = models.map((m) => ({
    value: String(m.id),
    label: m.marca ? `${m.marca} ${m.nombre}` : m.nombre,
  }))

  const selectedClient = clients.find((c) => String(c.id) === cliente_id)
  const selectedPrinterDetails = printers.filter((p) => selectedPrinters.includes(p.id))

  const getPlanRows = () =>
    planRows
      .filter((r) => r.modelo_id)
      .map((r) => ({
        modelo_id: parseInt(r.modelo_id),
        cantidad: parseInt(r.cantidad) || 1,
      }))

  const planTotal = getPlanRows().reduce((s, r) => s + r.cantidad, 0)
  const pendientesInstalacion = Math.max(0, planTotal - selectedPrinters.length)
  const fechaInstalacionEfectiva = fechaVisitaInstalacion || fecha_inicio

  const getPlanModelLabel = (modeloId: string) => {
    const m = models.find((mm) => String(mm.id) === modeloId)
    return m ? (m.marca ? `${m.marca} ${m.nombre}` : m.nombre) : modeloId
  }

  const addPlanRow = () => {
    const usedIds = new Set(planRows.map((r) => r.modelo_id).filter(Boolean))
    const firstFree = modelOptions.find((o) => !usedIds.has(o.value))
    setPlanRows([
      ...planRows,
      { modelo_id: firstFree?.value ?? '', cantidad: '1' },
    ])
  }

  const updatePlanRow = (index: number, patch: Partial<PlanRow>) => {
    setPlanRows(planRows.map((r, i) => (i === index ? { ...r, ...patch } : r)))
  }

  const removePlanRow = (index: number) => {
    setPlanRows(planRows.filter((_, i) => i !== index))
  }

  const canNext = () => {
    if (step === 0) return !!cliente_id && !!fecha_inicio
    return true
  }

  const handleNext = () => {
    if (step < 3) setStep(step + 1)
    else setShowConfirm(true)
  }

  const handlePrev = () => {
    if (step > 0) setStep(step - 1)
  }

  const handleCreate = () => {
    setError('')
    const contractData = {
      cliente_id: parseInt(cliente_id),
      fecha_inicio,
      fecha_fin: fecha_fin || null,
      dias_gracia: parseInt(dias_gracia),
      frecuencia_visitas: frecuencia,
      dia_visita: dia_visita ? parseInt(dia_visita) : null,
      tarifa_base: parseFloat(tarifa_base),
      paginas_incluidas: parseInt(paginas_incluidas),
      costo_pag_excedente: parseFloat(costo_por_pagina_excedente),
      plan_impresoras: getPlanRows(),
      impresoras: selectedPrinters.map((printerId) => ({
        id: printerId,
        lectura_inicial: getLecturaInicial(printerId),
        alias: aliases[printerId]?.trim() || null,
      })),
      ...(pendientesInstalacion > 0
        ? {
            programar_visita_instalacion: programarVisitaInstalacion,
            fecha_visita_instalacion: programarVisitaInstalacion ? fechaInstalacionEfectiva : null,
          }
        : {}),
    }
    
    createContract.mutate(contractData, {
      onSuccess: () => {
        setShowConfirm(false)
        setShowSuccess(true)
      },
      onError: (err) => {
        setError(parseApiError(err))
      },
    })
  }

  const handleSuccessClose = () => {
    setShowSuccess(false)
    navigate('/contratos')
  }

  const getLecturaInicial = (printerId: string) => {
    const entered = lecturas_iniciales[printerId]
    if (entered !== undefined && entered !== '') {
      const parsed = parseInt(entered)
      if (!isNaN(parsed)) return parsed
    }
    const printer = printers.find((p) => p.id === printerId)
    return printer?.contador_actual ?? 0
  }

  const togglePrinter = (id: string) => {
    if (selectedPrinters.includes(id)) {
      setSelectedPrinters(selectedPrinters.filter((p) => p !== id))
      return
    }
    const printer = printers.find((p) => p.id === id)
    setSelectedPrinters([...selectedPrinters, id])
    setLecturasIniciales((prev) => ({
      ...prev,
      [id]: String(printer?.contador_actual ?? 0),
    }))
  }

  if (clientsLoading || printersLoading || modelsLoading) {
    return (
      <PageLayout title="Contratos › Crear Nuevo Contrato">
        <div className="flex items-center justify-center py-12">
          <p className="text-muted-foreground">Cargando datos necesarios...</p>
        </div>
      </PageLayout>
    )
  }

  return (
    <PageLayout title="Contratos › Crear Nuevo Contrato">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <Button variant="ghost" size="sm" onClick={() => navigate('/contratos')}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Cancelar
          </Button>
        </div>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-8">
              {stepLabels.map((label, i) => {
                const Icon = stepIcons[i]
                const isActive = i === step
                const isCompleted = i < step
                return (
                  <div key={i} className="flex items-center gap-2">
                    <div
                      className={`flex h-8 w-8 items-center justify-center rounded-full text-sm font-medium ${
                        isActive
                          ? 'bg-primary text-white'
                          : isCompleted
                          ? 'bg-success text-white'
                          : 'bg-muted text-muted-foreground'
                      }`}
                    >
                      {isCompleted ? <Check className="h-4 w-4" /> : <Icon className="h-4 w-4" />}
                    </div>
                    <span className={`text-sm hidden sm:inline ${isActive ? 'font-medium text-primary' : 'text-muted-foreground'}`}>
                      {label}
                    </span>
                    {i < stepLabels.length - 1 && (
                      <div className={`w-8 lg:w-16 h-0.5 mx-1 ${i < step ? 'bg-success' : 'bg-muted'}`} />
                    )}
                  </div>
                )
              })}
            </div>

            <p className="text-lg font-semibold mb-6">
              PASO {step + 1} DE 4: {stepLabels[step]}
            </p>

            {step === 0 && (
              <div className="space-y-4 max-w-lg">
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-1">Cliente *</label>
                  <Select
                    options={clientOptions}
                    value={cliente_id}
                    onChange={setClienteId}
                    placeholder="Seleccionar cliente..."
                    searchable
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-1">Fecha de inicio *</label>
                  <Input
                    type="date"
                    value={fecha_inicio}
                    onChange={(e) => setFechaInicio(e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-1">
                    Fecha de fin (opcional, vacío = indefinido)
                  </label>
                  <Input
                    type="date"
                    value={fecha_fin}
                    onChange={(e) => setFechaFin(e.target.value)}
                    placeholder="Dejar indefinido"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-1">
                    {DIAS_GRACIA_LABEL} *
                  </label>
                  <Input
                    type="number"
                    value={dias_gracia}
                    onChange={(e) => setDiasGracia(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground mt-1">{DIAS_GRACIA_HELP}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-1">Frecuencia de visitas *</label>
                  <Select
                    options={frecuenciaOptions}
                    value={frecuencia}
                    onChange={(v) => setFrecuencia(v as VisitFrequency)}
                  />
                </div>
                {frecuencia === 'MENSUAL' && (
                  <div>
                    <label className="block text-sm font-medium text-muted-foreground mb-1">
                      Día de visita del mes (opcional)
                    </label>
                    <Select
                      options={[
                        { value: '', label: 'Derivar desde fecha de inicio' },
                        ...Array.from({ length: 31 }, (_, i) => ({
                          value: String(i + 1),
                          label: String(i + 1),
                        })),
                      ]}
                      value={dia_visita}
                      onChange={setDiaVisita}
                      placeholder="Día del mes (1-31)"
                    />
                  </div>
                )}
              </div>
            )}

            {step === 1 && (
              <div className="space-y-6">
                {selectedClient && (
                  <div className="bg-primary/10 rounded-lg p-3 text-sm">
                    <p className="font-medium text-primary">Cliente: {selectedClient.razon_social} ({selectedClient.nombre_contacto})</p>
                    <p className="text-primary">RFC: {selectedClient.rfc || '-'}</p>
                  </div>
                )}

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Package className="h-4 w-4 text-primary" />
                      <p className="text-sm font-medium text-foreground">Modelos contratados (recomendado)</p>
                    </div>
                    <Button variant="outline" size="sm" onClick={addPlanRow} disabled={modelOptions.length === 0}>
                      <Plus className="mr-1 h-3 w-3" />
                      Agregar modelo
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground mb-3">
                    Define qué modelos quedan contratados. Las series físicas se vinculan en campo al
                    momento de instalar (la app móvil captura la lectura inicial real).
                  </p>
                  {planRows.length === 0 ? (
                    <div className="border border-dashed border-border rounded-lg p-4 text-sm text-muted-foreground">
                      Sin plan de modelos. Puedes agregar los modelos contratados o dejarlo vacío y
                      asignar series directamente.
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {planRows.map((row, index) => {
                        const selectedModel = models.find((m) => String(m.id) === row.modelo_id)
                        const duplicado =
                          row.modelo_id &&
                          planRows.filter((r) => r.modelo_id === row.modelo_id).length > 1
                        return (
                          <div key={index} className="border border-border rounded-lg p-3">
                            <div className="grid gap-3 sm:grid-cols-[1fr_120px_auto] items-center">
                              <div>
                                <label className="block text-xs text-muted-foreground mb-1">Modelo</label>
                                <Select
                                  options={modelOptions}
                                  value={row.modelo_id}
                                  onChange={(v) => updatePlanRow(index, { modelo_id: v })}
                                  placeholder="Seleccionar modelo..."
                                  searchable
                                />
                              </div>
                              <div>
                                <label className="block text-xs text-muted-foreground mb-1">Cantidad</label>
                                <Input
                                  type="number"
                                  min={1}
                                  max={20}
                                  value={row.cantidad}
                                  onChange={(e) => updatePlanRow(index, { cantidad: e.target.value })}
                                />
                              </div>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="mt-5"
                                onClick={() => removePlanRow(index)}
                                title="Quitar modelo"
                              >
                                <Trash2 className="h-4 w-4 text-destructive" />
                              </Button>
                            </div>
                            {duplicado && (
                              <p className="text-xs text-destructive mt-2">
                                Este modelo está repetido en el plan; el servidor lo rechazará.
                              </p>
                            )}
                            {selectedModel && (
                              <p className="text-xs text-muted-foreground mt-2">
                                {getPlanModelLabel(row.modelo_id)} × {parseInt(row.cantidad) || 1}
                              </p>
                            )}
                          </div>
                        )
                      })}
                    </div>
                  )}
                </div>

                <div className="border border-border rounded-lg">
                  <button
                    type="button"
                    className="w-full flex items-center justify-between p-3 text-sm font-medium text-foreground hover:bg-muted/50 transition-colors"
                    onClick={() => setShowSeries(!showSeries)}
                  >
                    <span className="flex items-center gap-2">
                      <Printer className="h-4 w-4 text-muted-foreground" />
                      Asignar series ahora (opcional)
                      {selectedPrinters.length > 0 && (
                        <Badge variant="primary">{selectedPrinters.length}</Badge>
                      )}
                    </span>
                    <span>{showSeries ? '−' : '+'}</span>
                  </button>
                  {showSeries && (
                    <div className="space-y-3 p-3 pt-0 border-t border-border">
                      <p className="text-xs text-muted-foreground pt-2">
                        Reserva blanda: las series seleccionadas pasan a RENTADA desde hoy con la
                        lectura inicial indicada. Si el equipo se instala después, deja esta sección
                        vacía.
                      </p>
                      {printers.map((printer) => {
                        const isSelected = selectedPrinters.includes(printer.id)
                        return (
                          <div
                            key={printer.id}
                            className={`border rounded-lg p-4 cursor-pointer transition-colors ${
                              isSelected ? 'border-primary bg-primary/10' : 'border-border hover:border-input'
                            }`}
                            onClick={() => togglePrinter(printer.id)}
                          >
                            <div className="flex items-start gap-3">
                              <div
                                className={`mt-0.5 flex h-5 w-5 items-center justify-center rounded border ${
                                  isSelected ? 'bg-primary border-primary' : 'border-input'
                                }`}
                              >
                                {isSelected && <Check className="h-3 w-3 text-white" />}
                              </div>
                              <div className="flex-1">
                                <p className="font-medium text-foreground">
                                  {printer.id} - {printer.marca} {printer.modelo}
                                </p>
                                <p className="text-xs text-muted-foreground">SERIE: {printer.num_serie}</p>
                                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-2 text-xs">
                                  <div>
                                    <span className="text-muted-foreground">Costo:</span>{' '}
                                    <span className="text-muted-foreground">{formatCurrency(printer.costo_adquisicion)}</span>
                                  </div>
                                  <div>
                                    <span className="text-muted-foreground">Contador:</span>{' '}
                                    <span className="text-foreground font-medium">{Number(printer.contador_actual ?? 0).toLocaleString('es-MX')} hojas</span>
                                  </div>
                                  <div>
                                    <span className="text-muted-foreground">Almacén:</span>{' '}
                                    <span className="text-muted-foreground">{printer.warehouse?.nombre || '-'}</span>
                                  </div>
                                  <div>
                                    <Badge variant="printer_status" color={printer.estado}>
                                      EN ALMACÉN
                                    </Badge>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        )
                      })}
                      <p className="text-sm text-muted-foreground">
                        Seleccionadas: {selectedPrinters.length} impresora(s)
                        {selectedPrinterDetails.length > 0 && (
                          <span>
                            {' '}
                            ({selectedPrinterDetails
                              .map((p) => `${p.num_serie}: ${Number(p.contador_actual ?? 0).toLocaleString('es-MX')} hojas`)
                              .join(' • ')})
                          </span>
                        )}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-4 max-w-lg">
                {selectedClient && (
                  <p className="text-sm text-muted-foreground">
                    Cliente: <span className="font-medium">{selectedClient.razon_social}</span> • Impresoras: {selectedPrinters.length}
                  </p>
                )}

                <div className="bg-muted rounded-lg p-3 text-sm text-muted-foreground">
                  <code>monto = tarifa_base + max(0, páginas - incluidas) × costo_por_pagina_excedente</code>
                </div>

                <div className="flex flex-wrap gap-2">
                  <Button variant="outline" size="sm" onClick={() => {
                    const p = presetLabels.renta_fija
                    setTarifaBase(String(p.tarifa_base))
                    setPaginasIncluidas(String(p.paginas_incluidas))
                    setCostoPorPagina(String(p.costo_por_pagina_excedente))
                  }}>
                    Renta fija pura
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => {
                    const p = presetLabels.puro_consumo
                    setTarifaBase(String(p.tarifa_base))
                    setPaginasIncluidas(String(p.paginas_incluidas))
                    setCostoPorPagina(String(p.costo_por_pagina_excedente))
                  }}>
                    Puro consumo
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => {
                    const p = presetLabels.estandar
                    setTarifaBase(String(p.tarifa_base))
                    setPaginasIncluidas(String(p.paginas_incluidas))
                    setCostoPorPagina(String(p.costo_por_pagina_excedente))
                  }}>
                    Estándar
                  </Button>
                </div>

                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-1">Tarifa base mensual ($)</label>
                  <Input
                    type="number"
                    step="0.01"
                    value={tarifa_base}
                    onChange={(e) => setTarifaBase(e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-1">Páginas incluidas</label>
                  <Input
                    type="number"
                    value={paginas_incluidas}
                    onChange={(e) => setPaginasIncluidas(e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-1">Costo por página excedente ($)</label>
                  <Input
                    type="number"
                    step="0.001"
                    value={costo_por_pagina_excedente}
                    onChange={(e) => setCostoPorPagina(e.target.value)}
                  />
                </div>

                {selectedPrinterDetails.length > 0 && (
                  <div>
                    <p className="text-sm font-medium text-muted-foreground mb-2">Lecturas iniciales de contador:</p>
                    <div className="space-y-3">
                      {selectedPrinterDetails.map((printer) => (
                        <div key={printer.id}>
                          <div className="flex items-center gap-3">
                            <span className="text-sm text-muted-foreground min-w-[200px]">
                              {printer.id} - {printer.marca} {printer.modelo}
                            </span>
                            <Input
                              type="number"
                              placeholder={`Contador actual: ${(printer.contador_actual ?? 0).toLocaleString('es-MX')}`}
                              value={lecturas_iniciales[printer.id] || ''}
                              onChange={(e) =>
                                setLecturasIniciales({ ...lecturas_iniciales, [printer.id]: e.target.value })
                              }
                              className="w-40"
                            />
                            <span className="text-xs text-muted-foreground">
                              Contador actual: {Number(printer.contador_actual ?? 0).toLocaleString('es-MX')} hojas
                            </span>
                          </div>
                          <div className="flex items-center gap-3 mt-2">
                            <span className="text-sm text-muted-foreground min-w-[200px]">Alias / ubicación</span>
                            <Input
                              type="text"
                              placeholder="Ej. Recepción"
                              value={aliases[printer.id] || ''}
                              onChange={(e) =>
                                setAliases({ ...aliases, [printer.id]: e.target.value })
                              }
                              className="w-60"
                              maxLength={60}
                            />
                            <span className="text-xs text-muted-foreground">
                              Cómo la identifica el cliente en el sitio (opcional)
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {step === 3 && (
              <div className="space-y-4">
                <div className="bg-primary/10 rounded-lg p-4">
                  <p className="font-medium text-primary mb-2">Resumen del Contrato</p>
                  <div className="grid gap-2 sm:grid-cols-2 text-sm">
                    <div>
                      <span className="text-primary">Cliente:</span>{' '}
                      <span className="font-medium">{selectedClient?.razon_social} ({selectedClient?.nombre_contacto})</span>
                    </div>
                    <div>
                      <span className="text-primary">RFC:</span>{' '}
                      <span className="font-medium">{selectedClient?.rfc || '-'}</span>
                    </div>
                    {selectedClient?.correo && (
                      <div>
                        <span className="text-primary">Contacto:</span>{' '}
                        <span className="font-medium">{selectedClient.telefono}, {selectedClient.correo}</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="bg-success/10 rounded-lg p-4">
                  <p className="font-medium text-success mb-2">Fechas del Contrato</p>
                  <div className="grid gap-2 sm:grid-cols-2 text-sm">
                    <div>
                      <span className="text-success">Inicio:</span>{' '}
                      <span className="font-medium">{fecha_inicio}</span>
                    </div>
                    <div>
                      <span className="text-success">Fin:</span>{' '}
                      <span className="font-medium">{fecha_fin || 'Indefinido (renovación tácita)'}</span>
                    </div>
                    <div>
                      <span className="text-success">Días de gracia de lectura:</span>{' '}
                      <span className="font-medium">{dias_gracia} días</span>
                    </div>
                    <div>
                      <span className="text-success">Frecuencia:</span>{' '}
                      <span className="font-medium capitalize">{frecuencia}</span>
                    </div>
                  </div>
                </div>

                <div className="bg-warning/10 rounded-lg p-4">
                  <p className="font-medium text-warning mb-2">Esquema de Cobro</p>
                  <div className="bg-card rounded p-2 text-sm font-mono mb-2">
                    tarifa_base + max(0, p - {paginas_incluidas}) × {costo_por_pagina_excedente}
                  </div>
                  <div className="grid gap-2 sm:grid-cols-3 text-sm">
                    <div>
                      <span className="text-warning">Tarifa base:</span>{' '}
                      <span className="font-medium">{formatCurrency(Number(tarifa_base))}</span>
                    </div>
                    <div>
                      <span className="text-warning">Páginas incluidas:</span>{' '}
                      <span className="font-medium">{Number(paginas_incluidas).toLocaleString('es-MX')}</span>
                    </div>
                    <div>
                      <span className="text-warning">Costo excedente:</span>{' '}
                      <span className="font-medium">{formatCurrency(Number(costo_por_pagina_excedente))}/página</span>
                    </div>
                  </div>
                </div>

                {getPlanRows().length > 0 && (
                  <div className="bg-info/10 rounded-lg p-4">
                    <p className="font-medium text-info mb-2 flex items-center gap-2">
                      <Package className="h-4 w-4" />
                      Plan de Modelos ({getPlanRows().length})
                    </p>
                    <div className="space-y-1">
                      {getPlanRows().map((row, i) => (
                        <div key={i} className="flex items-center gap-3 text-sm">
                          <span className="font-medium">
                            {getPlanModelLabel(String(row.modelo_id))} × {row.cantidad}
                          </span>
                          <span className="text-muted-foreground">instalación en campo</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {pendientesInstalacion > 0 && (
                  <div className="bg-warning/10 rounded-lg p-4">
                    <p className="font-medium text-warning mb-2 flex items-center gap-2">
                      <ClipboardCheck className="h-4 w-4" />
                      Visita de Instalación
                    </p>
                    <div className="space-y-3">
                      <Checkbox
                        id="programar-visita-instalacion"
                        label="Programar visita de instalación"
                        checked={programarVisitaInstalacion}
                        onChange={(e) => setProgramarVisitaInstalacion(e.target.checked)}
                      />
                      <div className="max-w-xs">
                        <label className="block text-sm font-medium text-muted-foreground mb-1">
                          Fecha de la visita
                        </label>
                        <Input
                          type="date"
                          value={fechaInstalacionEfectiva}
                          onChange={(e) => setFechaVisitaInstalacion(e.target.value)}
                          disabled={!programarVisitaInstalacion}
                        />
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Quedan {pendientesInstalacion} equipo(s) por instalar. Tras vincular
                        las series desde la app móvil, el operador cierra la visita con el
                        botón «Completar visita».
                      </p>
                    </div>
                  </div>
                )}

                {selectedPrinterDetails.length > 0 && (
                  <div className="bg-primary/10 rounded-lg p-4">
                    <p className="font-medium text-primary mb-2">
                      Impresoras Asignadas ({selectedPrinterDetails.length})
                    </p>
                    <div className="space-y-2">
                      {selectedPrinterDetails.map((printer) => (
                        <div key={printer.id} className="flex items-center gap-3 text-sm">
                          <Printer className="h-4 w-4 text-primary" />
                          <span className="font-medium">{printer.id} - {printer.marca} {printer.modelo}</span>
                          <span className="text-primary">SERIE: {printer.num_serie}</span>
                          <span className="text-muted-foreground">
                            Lectura: {getLecturaInicial(printer.id).toLocaleString('es-MX')} páginas
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {getPlanRows().length === 0 && selectedPrinterDetails.length === 0 && (
                  <div className="bg-warning/10 border border-warning/30 rounded-lg p-4 text-sm text-warning">
                    El contrato quedará activo sin equipos; instala las impresoras desde la app de
                    campo (app móvil) en la primera visita.
                  </div>
                )}

                <div className="bg-muted rounded-lg p-3 text-sm text-muted-foreground">
                  El sistema generará automáticamente las visitas {frecuencia}es para este cliente.
                </div>
              </div>
            )}

            <div className="flex justify-between pt-6 border-t mt-8">
              <div>
                {step > 0 && (
                  <Button variant="secondary" onClick={handlePrev}>
                    ← Anterior
                  </Button>
                )}
              </div>
              <div className="flex gap-2">
                <Button variant="secondary" onClick={() => navigate('/contratos')}>
                  Cancelar
                </Button>
                <Button
                  onClick={handleNext}
                  disabled={!canNext()}
                >
                  {step === 3 ? 'Crear Contrato' : 'Siguiente →'}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Modal isOpen={showConfirm} onClose={() => setShowConfirm(false)} title="Confirmar Creación">
        <div className="space-y-3">
          <p className="text-sm text-muted-foreground">¿Estás seguro de que deseas crear este contrato?</p>
          <div className="text-sm space-y-1">
            <p><span className="text-muted-foreground">Cliente:</span> {selectedClient?.razon_social}</p>
            <p><span className="text-muted-foreground">Modelos en plan:</span> {getPlanRows().reduce((s, r) => s + r.cantidad, 0)}</p>
            <p><span className="text-muted-foreground">Series asignadas ahora:</span> {selectedPrinters.length}</p>
            <p><span className="text-muted-foreground">Tarifa base:</span> {formatCurrency(Number(tarifa_base))}</p>
          </div>
          {error && (
            <div className="bg-destructive/10 border border-destructive/20 text-destructive px-4 py-2 rounded text-sm">
              {error}
            </div>
          )}
          <div className="bg-warning/10 rounded p-3 text-xs text-warning space-y-1">
            <p>• Creará el contrato en estado ACTIVO</p>
            {selectedPrinters.length > 0 && (
              <p>• Las series seleccionadas pasarán a estado RENTADA</p>
            )}
            {getPlanRows().length > 0 && (
              <p>• Los modelos quedarán como plan de instalación en campo (sin cobro hasta vincular serie)</p>
            )}
            {pendientesInstalacion > 0 && programarVisitaInstalacion && (
              <p>
                • Programará una visita de instalación el {fechaInstalacionEfectiva} (pendiente
                instalar {pendientesInstalacion} equipo{pendientesInstalacion === 1 ? '' : 's'})
              </p>
            )}
            <p>• Generará visitas en el calendario</p>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="secondary" onClick={() => setShowConfirm(false)}>Cancelar</Button>
            <Button onClick={handleCreate} disabled={createContract.isPending}>
              {createContract.isPending ? 'Creando...' : 'Crear Contrato'}
            </Button>
          </div>
        </div>
      </Modal>

      <Modal isOpen={showSuccess} onClose={handleSuccessClose} title="Contrato Creado Exitosamente">
        <div className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-success/10">
              <Check className="h-8 w-8 text-success" />
            </div>
          </div>
          <div>
            <p className="font-medium">Contrato creado para {selectedClient?.razon_social}</p>
            <p className="text-sm text-muted-foreground">
              {selectedPrinters.length > 0
                ? `${selectedPrinters.length} impresoras asignadas: ${selectedPrinters.join(', ')}`
                : pendientesInstalacion > 0 && programarVisitaInstalacion
                ? `Visita de instalación programada el ${fechaInstalacionEfectiva}: vincula las ${pendientesInstalacion} serie(s) pendientes desde la app móvil.`
                : getPlanRows().length > 0
                ? 'Plan de modelos registrado; instala las series desde la app de campo.'
                : 'Contrato sin equipos; instala desde la app de campo.'}
            </p>
            <p className="text-sm text-muted-foreground mt-2">
              Las visitas se han programado en el calendario.
            </p>
          </div>
          <div className="flex justify-center gap-3">
            <Button variant="secondary" onClick={handleSuccessClose}>Cerrar</Button>
            <Button onClick={() => { setShowSuccess(false); navigate('/contratos') }}>
              Ver contratos
            </Button>
          </div>
        </div>
      </Modal>
    </PageLayout>
  )
}
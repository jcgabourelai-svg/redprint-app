import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import api from '@/lib/api'
import type { Printer } from '@/types/printer'
import type { PaginatedResponse } from '@/types/api'

export function usePrinters(params?: Record<string, string | number>) {
  return useQuery<PaginatedResponse<Printer>>({
    queryKey: ['printers', params],
    queryFn: () => api.get('/printers', { params }).then(r => r.data),
  })
}

export function useAllPrinters(enabled = true) {
  return useQuery<Printer[]>({
    queryKey: ['printers', 'all'],
    queryFn: () =>
      api.get('/printers', { params: { per_page: 500 } }).then(r => r.data.data as Printer[]),
    enabled,
  })
}

export function usePrinter(id: number) {
  return useQuery<Printer>({
    queryKey: ['printers', id],
    queryFn: () => api.get(`/printers/${id}`).then(r => r.data),
    enabled: !!id,
  })
}

export function useCreatePrinter() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (data: Record<string, unknown>) => api.post('/printers', data).then(r => r.data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['printers'] }) },
  })
}

export function useUpdatePrinter() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ id, ...data }: { id: number } & Record<string, unknown>) =>
      api.put(`/printers/${id}`, data).then(r => r.data),
    onSuccess: (_, { id }) => {
      qc.invalidateQueries({ queryKey: ['printers'] })
      qc.invalidateQueries({ queryKey: ['printers', id] })
    },
  })
}

export function useDeactivatePrinter() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ id, reason }: { id: number; reason?: string }) =>
      api.delete(`/printers/${id}`, reason ? { data: { reason } } : undefined).then(r => r.data),
    onSuccess: (_, { id }) => {
      qc.invalidateQueries({ queryKey: ['printers'], refetchType: 'none' })
      qc.removeQueries({ queryKey: ['printers', id] })
    },
  })
}

export function useDeletePrinter() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: number) => api.delete(`/printers/${id}/force`).then(r => r.data),
    onSuccess: (_, id) => {
      qc.invalidateQueries({ queryKey: ['printers'], refetchType: 'none' })
      qc.removeQueries({ queryKey: ['printers', id] })
    },
  })
}
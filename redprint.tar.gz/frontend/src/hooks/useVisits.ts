import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import api from '@/lib/api'
import type { Visit } from '@/types/operations'
import type { PaginatedResponse } from '@/types/api'

export function useVisits(params?: Record<string, string | number>) {
  return useQuery<PaginatedResponse<Visit>>({
    queryKey: ['visits', params],
    queryFn: () => api.get('/visits', { params }).then(r => r.data),
  })
}

export function useVisit(id: number) {
  return useQuery<Visit>({
    queryKey: ['visits', id],
    queryFn: () => api.get(`/visits/${id}`).then(r => r.data),
    enabled: !!id,
  })
}

export function useCreateVisit() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (data: Record<string, unknown>) => api.post('/visits', data).then(r => r.data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['visits'] }) },
  })
}

export function useCompleteVisit() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ id, ...data }: { id: number } & Record<string, unknown>) =>
      api.post(`/visits/${id}/complete`, data).then(r => r.data),
    onSuccess: (_, { id }) => {
      qc.invalidateQueries({ queryKey: ['visits'] })
      qc.invalidateQueries({ queryKey: ['visits', id] })
      qc.invalidateQueries({ queryKey: ['readings'] })
    },
  })
}

export function useRescheduleVisit() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ id, ...data }: { id: number } & Record<string, unknown>) =>
      api.post(`/visits/${id}/reschedule`, data).then(r => r.data),
    onSuccess: (_, { id }) => {
      qc.invalidateQueries({ queryKey: ['visits'] })
      qc.invalidateQueries({ queryKey: ['visits', id] })
    },
  })
}

export function useUpdateVisit() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ id, ...data }: { id: number } & Record<string, unknown>) =>
      api.put(`/visits/${id}`, data).then(r => r.data),
    onSuccess: (_, { id }) => {
      qc.invalidateQueries({ queryKey: ['visits'] })
      qc.invalidateQueries({ queryKey: ['visits', id] })
    },
  })
}

export function useDeleteVisit() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: number) => api.delete(`/visits/${id}`).then(r => r.data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['visits'] })
    },
  })
}

export function useGenerateVisits() {
  const qc = useQueryClient()
  return useMutation<{ message: string; creadas: number }>({
    mutationFn: () => api.post('/visits/generate').then(r => r.data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['visits'] })
    },
  })
}

export interface Socio {
  id: number
  nombre: string
}

export function useSocios(enabled = true) {
  return useQuery<Socio[]>({
    queryKey: ['visits', 'socios'],
    queryFn: () => api.get('/visits/socios').then(r => r.data),
    enabled,
  })
}

export interface VisitClientOption {
  id: number
  razon_social: string
  contratos: { id: number; codigo_negocio: string }[]
}

export function useVisitClientOptions() {
  return useQuery<VisitClientOption[]>({
    queryKey: ['visits', 'clientes'],
    queryFn: () => api.get('/visits/clientes').then(r => r.data),
  })
}